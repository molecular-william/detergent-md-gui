"""Reference-backed construction of immutable CG molecule compositions.

The builder deliberately accepts identifiers and choices only.  It reparses the
canonical Martini sugar file for every preview so browser state cannot become a
second source of topology truth.
"""
from __future__ import annotations

import hashlib
import math
from pathlib import Path

from ... import itp, martini3
from ..mappings.identity import canonical_sha256

SUGAR_RESIDUES = (
    "GLC", "MAN", "GAL", "FRUF", "LFUC", "LRHA", "RIBF", "XYL",
    "INO", "GLA", "GYN", "NMC", "LAC", "SUCR", "TREH",
)

_RECIPES = (
    {
        "id": "linear-c1", "name": "Linear C1", "version": 1,
        "carbons_per_bead": 4, "terminal_types": ("C1",),
    },
    {
        "id": "linear-c1-terminal", "name": "Linear C1/C2 terminal", "version": 1,
        "carbons_per_bead": 4, "terminal_types": ("C1", "C2"),
    },
)

_PROFILES = (
    {
        "id": "sugar-alkyl-ether-ddm-transfer",
        "name": "DDM sugar-to-alkyl ether transfer",
        "version": 1,
        "head_types": ("SP1r", "SP4r", "SN4ar", "TN4ar", "TP1"),
        "tail_types": ("C1", "C2"),
        "bond": {"function": 1, "length": 0.47, "force": 5000.0},
    },
)


def _sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def _section_blocks(text: str) -> list[tuple[str, list[str]]]:
    return [(name, [line for _number, line in rows]) for name, rows in itp.sections(text)]


def _tokens(rows: list[str], width: int | None = None) -> list[list[str]]:
    result = []
    for row in rows:
        parts = row.split()
        if width is None or len(parts) >= width:
            result.append(parts)
    return result


def load_sugar_catalog(source: Path) -> dict[str, dict]:
    """Parse all named moleculetype blocks from the canonical sugar ITP."""
    source = Path(source)
    if not source.is_file() or source.is_symlink():
        raise ValueError("Sugar source must be a regular file")
    blocks = _section_blocks(source.read_text())
    catalog: dict[str, dict] = {}
    current: dict | None = None
    section = None
    for name, rows in blocks:
        if name == "moleculetype":
            if not rows:
                raise ValueError("Sugar moleculetype is missing a name")
            residue = rows[0].split()[0]
            if residue in catalog:
                raise ValueError(f"Duplicate sugar residue {residue}")
            current = {"id": residue, "name": residue, "atoms": [], "bonds": [],
                       "constraints": [], "angles": [], "dihedrals": [],
                       "exclusions": [], "virtual_sites": []}
            catalog[residue] = current
            section = None
        elif current is not None:
            section = name
            if section == "atoms":
                for parts in _tokens(rows, 8):
                    # parts[2] is the residue number and parts[3] its name. A two-residue sugar names its beads
                    # A/B/C/VS inside each residue and lets the number tell the copies apart, so the number is
                    # kept: it is the only thing distinguishing the second ring's A from the first's.
                    current["atoms"].append({"index": int(parts[0]), "type": parts[1],
                        "residue": parts[3], "residue_number": int(parts[2]), "name": parts[4],
                        "charge": float(parts[6]), "mass": float(parts[7]), "virtual": False})
            elif section in ("bonds", "constraints"):
                target = current[section]
                for parts in _tokens(rows, 4):
                    target.append({"a": int(parts[0]), "b": int(parts[1]),
                                   "function": int(parts[2]), "length": float(parts[3])})
            elif section == "angles":
                for parts in _tokens(rows, 5):
                    current[section].append({"atoms": [int(parts[0]), int(parts[1]), int(parts[2])],
                                             "function": int(parts[3]), "parameters": [float(x) for x in parts[4:]]})
            elif section == "dihedrals":
                for parts in _tokens(rows, 6):
                    current[section].append({"atoms": [int(x) for x in parts[:4]],
                                             "function": int(parts[4]), "parameters": [float(x) for x in parts[5:]]})
            elif section == "exclusions":
                current["exclusions"].extend([[int(x) for x in row] for row in _tokens(rows)])
            elif section == "virtual_sitesn":
                for parts in _tokens(rows, 5):
                    current["virtual_sites"].append({"site": int(parts[0]), "parents": [int(x) for x in parts[2:]]})
    for residue, item in catalog.items():
        if not item["atoms"]:
            raise ValueError(f"Sugar residue {residue} has no atoms")
        # A two-residue sugar -- sucrose, lactose, trehalose -- repeats the bead names A/B/C/VS inside each of its
        # residues, exactly as the reference does, and relies on the residue number to tell the copies apart.
        # Everything downstream of this loader keys beads by name: the catalogue's bead and endpoint lists, the
        # panel's endpoint selections, the PDB writer's serial map and the viewer's index lookup. With a name
        # repeated, every one of them silently addresses the first residue's atoms -- sucrose drew as one ring
        # with the other ring's bonds pointing into it -- so the name is where the identity has to be unique.
        # Where a name occurs more than once, each occurrence carries its residue number; the single-residue
        # sugars keep the reference's own names.
        if len({atom["name"] for atom in item["atoms"]}) != len(item["atoms"]):
            for atom in item["atoms"]:
                atom["name"] = f'{atom["name"]}{atom["residue_number"]}'
        # Which beads are virtual sites is a property of the file, not of their names: the sites a moleculetype
        # declares in its virtual_sitesn section are the ones that are not physical beads. Readers that recognised
        # them by the name 'VS' stopped recognising them the moment a repeated name had to be disambiguated, and
        # the failure was silent in both directions -- a virtual site offered as a linkage endpoint, and a virtual
        # site with no coordinates drawn as if it were a bead.
        for site in item["virtual_sites"]:
            item["atoms"][site["site"] - 1]["virtual"] = True
        item["source_sha256"] = _sha256(source)
        item["source_path"] = str(source)
        item["bead_names"] = [atom["name"] for atom in item["atoms"]]
    return {key: catalog[key] for key in SUGAR_RESIDUES if key in catalog}


def tail_recipe_catalog() -> list[dict]:
    return [dict(item, terminal_types=list(item["terminal_types"])) for item in _RECIPES]


def linkage_profile_catalog() -> list[dict]:
    return [dict(item, head_types=list(item["head_types"]), tail_types=list(item["tail_types"])) for item in _PROFILES]


def _recipe(recipe_id: str) -> dict:
    for item in _RECIPES:
        if item["id"] == recipe_id:
            return item
    raise ValueError(f"Unknown tail recipe: {recipe_id}")


def expand_tail(recipe_id: str, carbon_count: int) -> dict:
    recipe = _recipe(recipe_id)
    if isinstance(carbon_count, bool) or not isinstance(carbon_count, int) or carbon_count < 2 or carbon_count > 200:
        raise ValueError("carbon count must be an integer between 2 and 200")
    count = math.ceil(carbon_count / recipe["carbons_per_bead"])
    beads = []
    for index in range(count):
        first = index * recipe["carbons_per_bead"] + 1
        last = min(carbon_count, (index + 1) * recipe["carbons_per_bead"])
        bead_type = recipe["terminal_types"][-1] if index == count - 1 and len(recipe["terminal_types"]) > 1 else recipe["terminal_types"][0]
        beads.append({"name": f"C{index + 1:02d}", "type": bead_type,
                      "carbon_range": [first, last], "mass": 54.0, "charge": 0.0})
    # The tail lies in the same z=0 plane as the head layout, so an initial composite starts coplanar: a line
    # and a circle share a plane. The bonded terms are seeded from this geometry, so a flat start seeds flat
    # torsions and the fitting stage has to correct them -- coplanar is a stated convention, not a conformer.
    coordinates = [[round(index * 0.47, 6), 0.0, 0.0] for index in range(count)]
    bonds = [{"a": beads[index - 1]["name"], "b": beads[index]["name"],
              "function": 1, "length": 0.47, "force": 5000.0} for index in range(1, count)]
    return {"recipe_id": recipe_id, "carbon_count": carbon_count, "beads": beads,
            "coordinates": coordinates, "bonds": bonds, "version": recipe["version"]}


def _profile(profile_id: str) -> dict:
    for item in _PROFILES:
        if item["id"] == profile_id:
            return item
    raise ValueError(f"Unknown linkage profile: {profile_id}")


def _sugar_source(project_root: Path | None) -> Path:
    """The sugar reference: this workspace's installed set unless a caller names its own project root.

    A caller-supplied root keeps the `references/` spelling on purpose -- the composition tests build a scratch
    tree there -- while None means the shared install, which is the same bytes every run simulates with.
    """
    if not project_root:
        return martini3.path("martini_v3.0.0_sugars_v2.itp")
    return Path(project_root) / "references" / "martini_v3.0.0_sugars_v2.itp"


def build_preview(payload: dict, project_root: Path | None = None) -> dict:
    if not isinstance(payload, dict):
        raise ValueError("Composition payload must be an object")
    head_id = str(payload.get("head_fragment_id", ""))
    residue = head_id.rsplit(":", 1)[-1]
    catalog = load_sugar_catalog(_sugar_source(project_root))
    if residue not in catalog:
        raise ValueError(f"Unknown sugar fragment: {head_id}")
    sugar = catalog[residue]
    supplied_hash = payload.get("source_sha256")
    if supplied_hash and supplied_hash != sugar["source_sha256"]:
        raise ValueError("Sugar source hash is stale")
    tail = expand_tail(str(payload.get("tail_recipe_id", "")), int(payload.get("carbon_count", 0)))
    profile = _profile(str(payload.get("linkage_profile_id", "")))
    head_endpoint = (payload.get("head_endpoint") or {}).get("bead")
    tail_endpoint = (payload.get("tail_endpoint") or {}).get("bead") or tail["beads"][0]["name"]
    head_atom = next((atom for atom in sugar["atoms"] if atom["name"] == head_endpoint), None)
    if head_atom is None or head_atom["virtual"]:
        raise ValueError("Head endpoint must be a physical sugar bead")
    if tail_endpoint not in {item["name"] for item in tail["beads"]}:
        raise ValueError("Tail endpoint must be a generated tail bead")
    if head_atom["type"] not in profile["head_types"]:
        raise ValueError(f"Linkage profile does not support head bead {head_endpoint}")
    tail_atom = next(item for item in tail["beads"] if item["name"] == tail_endpoint)
    if tail_atom["type"] not in profile["tail_types"]:
        raise ValueError(f"Linkage profile does not support tail bead {tail_endpoint}")
    offset = len(sugar["atoms"])
    atoms = [dict(atom, index=atom["index"], bead=atom["name"]) for atom in sugar["atoms"]]
    for index, bead in enumerate(tail["beads"], start=1):
        atoms.append({"index": offset + index, "type": bead["type"], "residue": residue,
                      "name": bead["name"], "bead": bead["name"], "charge": bead["charge"], "mass": bead["mass"]})
    bonds = [{"a": sugar["atoms"][term["a"] - 1]["name"], "b": sugar["atoms"][term["b"] - 1]["name"],
              "function": term["function"], "length": term["length"]} for term in sugar["constraints"]]
    bonds.extend({"a": term["a"], "b": term["b"], "function": term["function"], "length": term["length"]} for term in tail["bonds"])
    bonds.append({"a": head_endpoint, "b": tail_endpoint, **profile["bond"]})
    virtual_sites = [{"site": sugar["atoms"][item["site"] - 1]["name"],
                      "parents": [sugar["atoms"][index - 1]["name"] for index in item["parents"]]}
                     for item in sugar["virtual_sites"]]
    mapping_beads = [{"name": atom["name"], "type": atom["type"], "atoms": [atom["index"]],
                      "size": "R" if atom["mass"] >= 50 else "S", "virtual_site": bool(atom.get("virtual"))}
                     for atom in atoms]
    mapping = {"schema_version": 3, "name": payload.get("display_name") or f"{residue} C{payload.get('carbon_count')}",
               "residue_name": payload.get("residue_name") or residue, "beads": mapping_beads,
               "connections": [[bond["a"], bond["b"]] for bond in bonds if bond["a"] != bond["b"]],
               "source": {"head_fragment_id": head_id, "source_sha256": sugar["source_sha256"],
                          "tail_recipe_id": tail["recipe_id"], "linkage_profile_id": profile["id"]}}
    topology = {"atoms": atoms, "bonds": bonds, "virtual_sites": virtual_sites,
                "exclusions": [[virtual["site"], *virtual["parents"]] for virtual in virtual_sites]}
    result = {"mapping": mapping, "topology": topology, "tail": tail,
              "generated_terms": {"bonds": [bonds[-1]]}, "head": sugar,
              "profile": profile, "source_sha256": sugar["source_sha256"],
              "validation": {"structural": {"ok": True, "issues": []}, "chemical": {"ok": True, "issues": []}}}
    result["identity"] = composition_identity(result)
    result["itp"] = render_itp(result)
    result["gro"] = render_gro(result)
    return result


def validate_preview(result: dict) -> dict:
    if not result.get("mapping", {}).get("beads"):
        raise ValueError("Composition contains no beads")
    names = {bead["name"] for bead in result["mapping"]["beads"]}
    if any(edge["a"] not in names or edge["b"] not in names for edge in result["topology"]["bonds"]):
        raise ValueError("Topology references an unknown bead")
    return result["validation"]


def composition_identity(result: dict) -> str:
    payload = {"mapping": result.get("mapping", {}), "topology": result.get("topology", {}),
               "tail": result.get("tail", {}), "profile": result.get("profile", {}).get("id")}
    payload["mapping"] = {key: value for key, value in payload["mapping"].items() if key not in ("name", "display_name")}
    return canonical_sha256(payload)


def render_itp(result: dict) -> str:
    mapping = result["mapping"]
    lines = ["; generated immutable composition", "[ moleculetype ]", f"{mapping['residue_name']} 1", "", "[ atoms ]", "; nr type resnr residue atom cgnr charge mass"]
    for atom in result["topology"]["atoms"]:
        lines.append(f"{atom['index']:5d} {atom['type']:<6} 1 {mapping['residue_name']:<6} {atom['name']:<4} {atom['index']:4d} {atom['charge']: .4f} {atom['mass']: .2f}")
    lines += ["", "[ bonds ]"]
    index = {atom["name"]: atom["index"] for atom in result["topology"]["atoms"]}
    for bond in result["topology"]["bonds"]:
        if bond["a"] in index and bond["b"] in index:
            lines.append(f"{index[bond['a']]:5d} {index[bond['b']]:5d} {bond.get('function', 1):2d} {bond.get('length', 0.47):.5f} {bond.get('force', 5000.0):.1f}")
    if result["topology"]["virtual_sites"]:
        lines += ["", "[ virtual_sitesn ]"]
        for site in result["topology"]["virtual_sites"]:
            lines.append(" ".join([str(index[site["site"]]), "1", *[str(index[parent]) for parent in site["parents"]]]))
    return "\n".join(lines) + "\n"


def preview_geometry(result: dict) -> dict:
    """Per-fragment CG bead positions for the combined-geometry panel.

    The tail's positions are the recipe's own (`tail['coordinates']`, which `render_gro` writes too), laid
    in the same z=0 plane as the head layout so an initial composite is coplanar: a line and a circle share
    a plane. That is a stated convention for a starting geometry, not a conformer -- the head's are a
    *layout* from its bead set, since the composition catalog does not carry the sugar's reference
    positions, and the joint bonds are seeded from these coordinates, so the fitting stage corrects what the
    flat start implies. The joined view translates the tail so its endpoint sits beside the head's, which is
    a preview arrangement -- nothing is minimised, and this is the mapped CG molecule, not the atomistic one.
    """
    import math
    tail = result["tail"]
    mapping_beads = result["mapping"]["beads"]
    tail_names = [bead["name"] for bead in tail["beads"]]
    by_name = {bead["name"]: bead for bead in mapping_beads}
    head_names = [bead["name"] for bead in mapping_beads
                  if bead["name"] not in tail_names and not bead.get("virtual_site")]
    head_beads = []
    for index, bead_name in enumerate(head_names):
        angle = 2 * math.pi * index / max(1, len(head_names))
        head_beads.append({"name": bead_name, "type": by_name[bead_name].get("type"),
                           "size": by_name[bead_name].get("size"),
                           "position": [round(0.35 * math.cos(angle), 3), round(0.35 * math.sin(angle), 3), 0.0]})
    tail_beads = [{"name": bead["name"], "type": bead["type"],
                   "size": "R" if bead.get("mass", 0) >= 50 else "S",
                   "position": [float(value) for value in coordinate]}
                  for bead, coordinate in zip(tail["beads"], tail["coordinates"])]

    def edges_within(names):
        wanted = set(names)
        return [[term["a"], term["b"]] for term in result["topology"]["bonds"]
                if term["a"] in wanted and term["b"] in wanted]

    head_set, tail_set = set(head_names), set(tail_names)
    link = next(([term["a"], term["b"]] for term in result["topology"]["bonds"]
                 if (term["a"] in head_set and term["b"] in tail_set)
                 or (term["b"] in head_set and term["a"] in tail_set)), [])
    offset = [0.0, 0.0, 0.0]
    if link:
        head_at = next((bead["position"] for bead in head_beads if bead["name"] == link[0]), [0.0, 0.0, 0.0])
        tail_at = next((bead["position"] for bead in tail_beads if bead["name"] == link[1]), [0.0, 0.0, 0.0])
        offset = [head_at[index] + (0.47 if index == 0 else 0.0) - tail_at[index] for index in range(3)]
    joined = head_beads + [{**bead, "position": [round(bead["position"][index] + offset[index], 3)
                                                 for index in range(3)]} for bead in tail_beads]
    return {
        "head": {"beads": head_beads, "edges": edges_within(head_names)},
        "tail": {"beads": tail_beads, "edges": edges_within(tail_names)},
        "joined": {"beads": joined, "edges": edges_within(head_names + tail_names), "link": link},
        "link": {"head_bead": link[0] if link else "", "tail_bead": link[1] if link else ""},
        "basis": ("Head positions are a layout from its bead set; tail positions come from the recipe. "
                  "Nothing is minimised, and this is the mapped CG molecule rather than the atomistic one."),
    }


def render_pdb(result: dict) -> str:
    """The composite as a PDB, for a molecular viewer (NGL, 3Dmol, Mol*).

    One HETATM per bead, at the positions `preview_geometry` gives, so the file shows the joined preview
    arrangement the panel draws: a layout convention, not a minimised structure. Coordinates are written in
    Angstrom because the format is, while the CG positions are nanometres.

    The element is a *radius stand-in* chosen from the bead's size class (R/S/T -> C/N/H) so that a viewer's
    per-element radii come out in proportion to 0.264/0.230/0.191 nm. C/N/H are the stand-ins whose van der
    Waals radii divide by the same factor into those three targets, which lets one radius scale serve every
    class. It says nothing about chemistry, and virtual sites are left out: a massless site is not an atom, and
    it would render as one.
    """
    geometry = preview_geometry(result)
    head_names = {bead["name"] for bead in geometry["head"]["beads"]}
    elements = {"R": "C", "S": "N", "T": "H"}
    serials: dict[str, int] = {}
    remarks = ["REMARK 950 CG COMPOSITION AS A PDB: ONE ATOM PER BEAD, A LAID-OUT ARRANGEMENT, NOT A MINIMISED STRUCTURE",
               "REMARK 950 COLOUR BY TYPE USING THE BEAD LINES BELOW; THE ELEMENT FIELD ONLY CARRIES A RADIUS STAND-IN"]
    atoms = []
    for serial, bead in enumerate(geometry["joined"]["beads"], start=1):
        name = str(bead["name"])[:4]
        bead_type = str(bead.get("type") or "")
        size = str(bead.get("size") or "")
        serials[name] = serial
        position = [round(float(value) * 10.0, 3) for value in bead["position"]]
        element = elements.get(size, "C")
        residue = "SUG" if name in head_names else "TAI"
        remarks.append(f"REMARK 950 BEAD {name} {bead_type} {size} {residue}")
        atoms.append(f"HETATM{serial:5d} {name:<4s} {residue:>3s} A{1:4d}    "
                     f"{position[0]:8.3f}{position[1]:8.3f}{position[2]:8.3f}"
                     f"{1.0:6.2f}{0.0:6.2f}          {element:>2s}")
    lines = remarks + atoms
    pairs = [list(edge) for edge in geometry["joined"]["edges"]]
    link = geometry["joined"]["link"]
    if link:
        pairs.append(list(link))
    for first, second in dict.fromkeys((pair[0], pair[1]) for pair in pairs):
        if first in serials and second in serials:
            lines.append(f"CONECT{serials[first]:5d}{serials[second]:5d}")
    lines.append("END")
    return "\n".join(lines) + "\n"


def render_gro(result: dict) -> str:
    atoms = result["topology"]["atoms"]
    tail_coordinates = result["tail"]["coordinates"]
    coords = {atom["name"]: [0.0, 0.0, 0.1 * (atom["index"] - 1)] for atom in atoms}
    for bead, coord in zip(result["tail"]["beads"], tail_coordinates):
        coords[bead["name"]] = coord
    lines = ["Generated composition", str(len(atoms))]
    for index, atom in enumerate(atoms, 1):
        x, y, z = coords[atom["name"]]
        lines.append(f"    1{result['mapping']['residue_name'][:5]:<5}{atom['name'][:5]:>5}{index:5d}{x:8.3f}{y:8.3f}{z:8.3f}")
    lines.append("   3.00000   3.00000   3.00000")
    return "\n".join(lines) + "\n"


def parse_composite_itp(text: str) -> dict:
    atoms = []
    in_atoms = False
    for raw in text.splitlines():
        line = raw.split(";", 1)[0].strip()
        if line.startswith("["):
            in_atoms = line.strip("[] ").lower() == "atoms"
            continue
        if in_atoms and line:
            parts = line.split()
            if len(parts) >= 8 and parts[0].isdigit():
                atoms.append({"index": int(parts[0]), "type": parts[1], "name": parts[4], "mass": float(parts[7])})
    return {"atoms": atoms}


def parse_composite_gro(text: str) -> dict:
    rows = text.splitlines()
    return {"atom_count": int(rows[1]) if len(rows) > 1 else 0}
