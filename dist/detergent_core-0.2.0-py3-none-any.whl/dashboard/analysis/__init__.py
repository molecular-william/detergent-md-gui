"""Dashboard analysis modules."""
